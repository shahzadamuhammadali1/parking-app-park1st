package com.dev175.agent.activity;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.dev175.agent.R;
import com.dev175.agent.databinding.ActivityAppointmentDetailsBinding;
import com.dev175.agent.model.Appointment;
import com.dev175.agent.model.Constant;
import com.dev175.agent.model.ParkingSlot;
import com.dev175.agent.model.User;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AppointmentDetailsActivity extends AppCompatActivity {

    //For Binding
    private ActivityAppointmentDetailsBinding binding;
    private Appointment appointment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAppointmentDetailsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        init();
    }

    private void init(){
        getSupportActionBar().setTitle("Parking Details");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        appointment = (Appointment) getIntent().getSerializableExtra(Constant.APPOINTMENT);

        if (appointment.getParkingSlot().getStatus().equals(Constant.NOT_CONFIRMED))
        {
            binding.confirmAppointment.setVisibility(View.VISIBLE);
        }
        else if (appointment.getParkingSlot().getStatus().equals(Constant.CONFIRMED))
        {
            binding.doneAppointment.setVisibility(View.VISIBLE);
        }
        if (appointment.getParkingSlot().getStatus().equals(Constant.COMPLETED))
        {
            binding.cancelAppointment.setVisibility(View.GONE);
        }

        //Set Data
        Glide.with(AppointmentDetailsActivity.this)
                .load(appointment.getUser().getUri())
                .placeholder(R.drawable.ic_user)
                .into(binding.patientProfileImg);

        binding.patientName.setText(appointment.getUser().getName());
        binding.email.setText(appointment.getUser().getEmail());
        binding.phone.setText(appointment.getUser().getPhoneNumber());
        binding.address.setText(appointment.getUser().getAddress());
        binding.slot.setText(String.valueOf(appointment.getParkingSlot().getSlot()));
        binding.type.setText(appointment.getParkingSlot().getType());
        binding.status.setText(appointment.getParkingSlot().getStatus());


        //Done Appointment Button Click Listener
        binding.doneAppointment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doneAppointment();
            }
        });

        //Cancel Appointment Button Click Listener
        binding.cancelAppointment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cancelAppointment();
            }
        });

        //Confirm Appointment Button Click Listener
        binding.confirmAppointment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmAppointment();
            }
        });

    }

    private void confirmAppointment() {
        String uid = FirebaseAuth.getInstance().getUid();

        DatabaseReference database = FirebaseDatabase.getInstance().getReference();

        String patientDocId = appointment.getUser().getUid()+"_"+uid;

        database.child(Constant.USER_APPOINTMENTS)
                .child(patientDocId)
                .child(appointment.getParkingSlot().getUid())
                .child(Constant.STATUS)
                .setValue(Constant.CONFIRMED)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {

                        database.child(Constant.ROOT_PARKING)
                                .child(uid)
                                .child(String.valueOf(appointment.getParkingSlot().getSlot()))
                                .child(Constant.STATUS)
                                .setValue(Constant.CONFIRMED);

                        Toast.makeText(AppointmentDetailsActivity.this, "Booking Confirmed Successfully!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(AppointmentDetailsActivity.this,HomeActivity.class));
                        finishAffinity();
                    }
                });
    }

    private void cancelAppointment() {
        User patient = appointment.getUser();
        ParkingSlot timeslot = appointment.getParkingSlot();

        DatabaseReference database = FirebaseDatabase.getInstance().getReference();
        String uid = FirebaseAuth.getInstance().getUid();
        String patientDocId = patient.getUid()+"_"+uid;
        database.child(Constant.USER_APPOINTMENTS)
                .child(patientDocId)
                .child(timeslot.getUid())
                .removeValue()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        database.child(Constant.ROOT_PARKING)
                                .child(uid)
                                .child(String.valueOf(timeslot.getSlot()))
                                .removeValue();

                        Toast.makeText(AppointmentDetailsActivity.this, "Booking Cancel Successfully!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(AppointmentDetailsActivity.this,HomeActivity.class));
                        finishAffinity();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull  Exception e) {
                        Toast.makeText(AppointmentDetailsActivity.this, "Failed to cancel Appointment!", Toast.LENGTH_SHORT).show();
                    }
                });

    }

    private void doneAppointment() {
        String uid = FirebaseAuth.getInstance().getUid();

        DatabaseReference database = FirebaseDatabase.getInstance().getReference();

        String patientDocId = appointment.getUser().getUid()+"_"+uid;

        database.child(Constant.USER_APPOINTMENTS)
                .child(patientDocId)
                .child(appointment.getParkingSlot().getUid())
                .child(Constant.STATUS)
                .setValue(Constant.COMPLETED)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {

                        database.child(Constant.ROOT_PARKING)
                                .child(uid)
                                .child(String.valueOf(appointment.getParkingSlot().getSlot()))
                                .removeValue();

                        Toast.makeText(AppointmentDetailsActivity.this, "Booking Completed Successfully!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(AppointmentDetailsActivity.this,HomeActivity.class));
                        finishAffinity();
                    }
                });
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}