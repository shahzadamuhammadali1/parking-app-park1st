package com.dev175.agent.activity;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.dev175.agent.adapter.AppointmentsAdapter;
import com.dev175.agent.databinding.ActivityAppointmentsBinding;
import com.dev175.agent.model.Appointment;
import com.dev175.agent.model.Constant;
import com.dev175.agent.model.ParkingSlot;
import com.dev175.agent.model.User;
import com.dev175.agent.myInterface.IOnItemClick;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class AppointmentsActivity extends AppCompatActivity implements IOnItemClick {

    //For Binding
    private ActivityAppointmentsBinding binding;

    private DatabaseReference database;
    private static final String TAG = "AppointmentsActivity";

    private ArrayList<Appointment> appointmentsList;
    private AppointmentsAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAppointmentsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        init();
        getAppointments();

    }
    private void init()
    {
        getSupportActionBar().setTitle("Parkings");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        database = FirebaseDatabase.getInstance().getReference();
        appointmentsList = new ArrayList<>();

        adapter = new AppointmentsAdapter(this,this);
        adapter.setAppointments(appointmentsList);
        binding.appointmentsRv.setLayoutManager(new LinearLayoutManager(this));
        binding.appointmentsRv.setAdapter(adapter);

    }

    private void getAppointments() {

        binding.progressCircular.setVisibility(View.VISIBLE);

        database.child(Constant.USER_APPOINTMENTS)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        int count = 0;

                        for (DataSnapshot snapshot : dataSnapshot.getChildren())
                        {
                            count++;
                            String[] keys = snapshot.getKey().split("_");
                            String uid = FirebaseAuth.getInstance().getUid();

                            if (keys[1].equals(uid))
                            {

                                database.child(Constant.ROOT_USER)
                                        .child(keys[0])
                                        .addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot docSnap) {
                                                User patient =  docSnap.getValue(User.class);

                                                for (DataSnapshot dataSnapshot:snapshot.getChildren())
                                                {
                                                    ParkingSlot timeslot =  dataSnapshot.getValue(ParkingSlot.class);

                                                        Appointment appointment = new Appointment(patient,timeslot);
                                                        appointmentsList.add(appointment);


                                                }

                                                adapter.notifyDataSetChanged();


                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError error) {

                                            }
                                        });


                            }


                        }
                        if (count>=dataSnapshot.getChildrenCount())
                        {
                            binding.progressCircular.setVisibility(View.GONE);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull  DatabaseError error) {
                        binding.progressCircular.setVisibility(View.GONE);
                        Toast.makeText(AppointmentsActivity.this, ""+error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onItemClick(int position) {
        Appointment appointment = appointmentsList.get(position);
        Intent intent = new Intent(AppointmentsActivity.this,AppointmentDetailsActivity.class);
        intent.putExtra(Constant.APPOINTMENT,appointment);
        startActivity(intent);
    }
}