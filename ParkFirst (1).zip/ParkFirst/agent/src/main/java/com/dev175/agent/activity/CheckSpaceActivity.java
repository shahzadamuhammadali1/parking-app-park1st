package com.dev175.agent.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.dev175.agent.R;
import com.dev175.agent.databinding.ActivityCheckSpaceBinding;
import com.dev175.agent.model.Constant;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class CheckSpaceActivity extends AppCompatActivity {

    //For Binding
    private ActivityCheckSpaceBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCheckSpaceBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        init();
        getParkingsCount();
    }

    private void getParkingsCount() {
        String uid = FirebaseAuth.getInstance().getUid();
        FirebaseDatabase.getInstance().getReference().child(Constant.ROOT_PARKING)
                .child(uid)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull  DataSnapshot snapshot) {
                        long available = 40 -snapshot.getChildrenCount();
                        binding.availableSpace.setText(String.valueOf(available));
                    }

                    @Override
                    public void onCancelled(@NonNull  DatabaseError error) {

                    }
                });
    }

    private void init()
    {
        getSupportActionBar().setTitle("Check Spaces");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        binding.totalSpace.setText(String.valueOf(40));
    }


    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return super.onSupportNavigateUp();
    }
}