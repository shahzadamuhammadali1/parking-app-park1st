package com.dev175.agent.activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.dev175.agent.databinding.ActivityConfirmBinding;
import com.dev175.agent.model.Agent;
import com.dev175.agent.model.Constant;
import com.dev175.agent.model.ParkingSlot;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ConfirmActivity extends AppCompatActivity {

    private ActivityConfirmBinding binding;
    private Agent agent;
    private ParkingSlot timeslot;
    private DatabaseReference database;
    private String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityConfirmBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        init();

    }

    private void checkUserParking() {
        String email = binding.email.getText().toString().trim();

//        database.child(Constant.ROOT_EMAILS)
//                .addChildEventListener(new ChildEventListener() {
//                    @Override
//                    public void onChildAdded(@NonNull  DataSnapshot snapshot, @Nullable  String previousChildName) {
//
//
//                    }
//
//                    @Override
//                    public void onChildChanged(@NonNull  DataSnapshot snapshot, @Nullable String previousChildName) {
//
//                    }
//
//                    @Override
//                    public void onChildRemoved(@NonNull DataSnapshot snapshot) {
//
//                    }
//
//                    @Override
//                    public void onChildMoved(@NonNull  DataSnapshot snapshot, @Nullable String previousChildName) {
//
//                    }
//
//                    @Override
//                    public void onCancelled(@NonNull DatabaseError error) {
//
//                    }
//                });

        database.child(Constant.ROOT_EMAILS)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        int count = 0;
                        for (DataSnapshot snapshot : dataSnapshot.getChildren())
                        {
                            count++;
                            if (snapshot.exists())
                            {
                                String uEmail = snapshot.getValue(String.class);
                                if (email.equals(uEmail))
                                {
                                    userId = snapshot.getKey();

                                    String key = database.push().getKey();
                                    timeslot.setAgentId(agent.getUid());
                                    timeslot.setUserId(userId);
                                    timeslot.setUid(key);
                                    timeslot.setStatus(Constant.CONFIRMED);
                                    timeslot.setVehichleNum(binding.vehicleNum.getText().toString());
                                    database.child(Constant.ROOT_PARKING)
                                            .child(agent.getUid())
                                            .child(String.valueOf(timeslot.getSlot()))
                                            .setValue(timeslot)
                                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                @Override
                                                public void onSuccess(Void unused) {
                                                    saveUserAppointment();
                                                    Toast.makeText(ConfirmActivity.this, "Booking Successful!", Toast.LENGTH_SHORT).show();
                                                    Intent intent = new Intent(ConfirmActivity.this,HomeActivity.class);
                                                    startActivity(intent);
                                                    finishAffinity();
                                                }
                                            });


                                }

                            }

                        }
                        
                        if (count==dataSnapshot.getChildrenCount())
                        {
                         if (userId.equals(""))
                         {
                             Toast.makeText(ConfirmActivity.this, "User is not registered on the app", Toast.LENGTH_SHORT).show();
                         }
                         
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull  DatabaseError error) {

                    }
                });


        String userAgentId = userId+"_"+ agent.getUid();
        database.child(Constant.USER_APPOINTMENTS)
                .child(userAgentId)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        if (snapshot.exists())
                        {
                            Toast.makeText(ConfirmActivity.this, "You have already booked a parking!", Toast.LENGTH_SHORT).show();
                            return;
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull  DatabaseError error) {

                    }
                });
    }

    private void init() {
        getSupportActionBar().setTitle("Confirm Booking");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        agent = (Agent) getIntent().getSerializableExtra(Constant.AGENT);
        timeslot = (ParkingSlot) getIntent().getSerializableExtra(Constant.TIMESLOT);
        database = FirebaseDatabase.getInstance().getReference();
        userId = "";

        if (timeslot!=null)
        {
            binding.slot.setText(String.valueOf(timeslot.getSlot()));
            binding.type.setText(new StringBuilder(Constant.convertParkingSlotToString(timeslot.getSlot())));
        }


        binding.confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (binding.vehicleNum.getText().toString().isEmpty())
                {
                    binding.vehicleLyt.setError("\u2022 Vehicle number is Required!");
                    return;
                }
                else
                {
                    binding.vehicleLyt.setErrorEnabled(false);
                }

                if (binding.email.getText().toString().isEmpty())
                {
                    binding.emailLyt.setError("\u2022 Email is Required!");
                    return;
                }
                else
                {
                    binding.vehicleLyt.setErrorEnabled(false);
                }

                checkUserParking();


            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    private void saveUserAppointment() {
        database.child(Constant.USER_APPOINTMENTS)
                .child(userId+"_"+ agent.getUid())
                .child(timeslot.getUid())
                .setValue(timeslot);
    }
}