package com.dev175.agent.activity;


import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.dev175.agent.R;
import com.dev175.agent.databinding.ActivityEditProfileBinding;
import com.dev175.agent.model.Constant;
import com.dev175.agent.model.Agent;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class EditProfileActivity extends AppCompatActivity {


    //For Binding
    private ActivityEditProfileBinding binding;

    //User
    private Agent user;

    //Db Reference
    private StorageReference userImagesRef;
    private DatabaseReference userRef;


    //Selected Image Uri
    private Uri imageUri;

    private ActivityResultLauncher<Intent> imagePickerLaunch;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEditProfileBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);
        getSupportActionBar().setTitle("Edit Profile");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        user = new Agent();

        //Set All Fields Data
        setFields();

        init();

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return super.onSupportNavigateUp();
    }

    private void init() {

        String uid = FirebaseAuth.getInstance().getUid();

        userImagesRef= FirebaseStorage.getInstance().getReference().child(Constant.ROOT_AGENT).child(uid+".jpg");
        userRef = FirebaseDatabase.getInstance().getReference().child(Constant.ROOT_AGENT).child(uid);

        //User Profile Click listener
        binding.userProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectImageFromGallery();
            }
        });

        //Update
        binding.updateProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateUser();
            }
        });

        // Create lanucher variable inside onAttach or onCreate or global
        imagePickerLaunch = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK && result.getData()!=null)
                        {
                            Intent data = result.getData();

                            imageUri=data.getData();
                            Glide.with(EditProfileActivity.this)
                                    .load(imageUri)
                                    .placeholder(R.drawable.ic_user)
                                    .into(binding.userProfile);
                        }
                    }
                });
    }

    //Set All Fields using Product Obj
    private void setFields() {

        //Setting Image
        Glide.with(EditProfileActivity.this)
                .load(Constant.currentUser.getUri())
                .placeholder(R.drawable.ic_user)
                .into(binding.userProfile);

        //Setting TextFields
        binding.name.setText(Constant.currentUser.getName());
        binding.email.setText(Constant.currentUser.getEmail());
        binding.phone.setText(Constant.currentUser.getPhoneNumber());
        binding.address.setText(Constant.currentUser.getAddress());



    }


    private void selectImageFromGallery() {
        try
        {
            Intent objectIntent = new Intent();
            objectIntent.setType("image/*");
            objectIntent.setAction(Intent.ACTION_GET_CONTENT);
            imagePickerLaunch.launch(objectIntent);
        }
        catch (Exception e){
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private boolean validateLoginFields() {
        boolean isValid = true;

        //Name
        if (binding.name.getText().toString().isEmpty())
        {
            binding.nameLyt.setError("\u2022 Name is Required!");
            isValid = false;
        }
        else
        {
            binding.nameLyt.setErrorEnabled(false);
        }


        //Phone Number
        if (binding.phone.getText().toString().isEmpty())
        {
            binding.phoneLyt.setError("\u2022 Phone Number is Required!");
            isValid = false;
        }
        else
        {
            binding.phoneLyt.setErrorEnabled(false);
        }


        //Address
        if (binding.address.getText().toString().isEmpty())
        {
            binding.addressLyt.setError("\u2022 Address is Required!");
            isValid = false;
        }
        else
        {
            binding.addressLyt.setErrorEnabled(false);
        }

        return isValid;

    }

    private void storeUserInformation() {

        //Show Progress and Hide Button
        binding.updateProfile.setVisibility(View.GONE);
        binding.progressCircular.setVisibility(View.VISIBLE);


        user.setName(binding.name.getText().toString());
        user.setPhoneNumber(binding.phone.getText().toString());
        user.setAddress(binding.address.getText().toString());
        user.setEmail(binding.email.getText().toString());
        user.setUid(Constant.currentUser.getUid());

        //Optimize Img
        ExecutorService executors = Executors.newSingleThreadExecutor();
        executors.execute(new Runnable() {
            @Override
            public void run() {

                if (imageUri!=null)
                {


                    final UploadTask uploadTask = userImagesRef.putFile(imageUri);
                    uploadTask.addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            String message = e.toString();
                            Toast.makeText(EditProfileActivity.this, "Error : " + message, Toast.LENGTH_SHORT).show();

                            //Show Btn and Hide Progress
                            binding.progressCircular.setVisibility(View.GONE);
                            binding.updateProfile.setVisibility(View.VISIBLE);
                        }
                    }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            Task<Uri> uriTask = uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                                @Override
                                public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                                    if (!task.isSuccessful()) {
                                        throw task.getException();
                                    }

                                    return userImagesRef.getDownloadUrl();
                                }
                            }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                                @Override
                                public void onComplete(@NonNull Task<Uri> task) {
                                    if (task.isSuccessful()) {

                                        user.setUri(task.getResult().toString());
                                        updateUserInfoToDatabase();
                                    }
                                }
                            });
                        };
                    });


                }
                else
                {
                    //If User Does not select image
                    user.setUri(Constant.currentUser.getUri());
                    updateUserInfoToDatabase();
                }

            }

        });

    }



    private void updateUser() {
        boolean checkFields = validateLoginFields();

        if (checkFields)
        {
            storeUserInformation();
        }
    }


    private void updateUserInfoToDatabase() {

        Map<String,Object> map = new HashMap<>();
        map.put("uid",user.getUid());
        map.put("name",user.getName());
        map.put("email",user.getEmail());
        map.put("phoneNumber",user.getPhoneNumber());
        map.put("address",user.getAddress());
        map.put("uri",user.getUri());


        userRef.updateChildren(map)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Constant.currentUser = user;
                        Toast.makeText(EditProfileActivity.this, "Profile Updated", Toast.LENGTH_SHORT).show();
                        imageUri=null;

                        //Show btn and Hide progress
                        binding.updateProfile.setVisibility(View.VISIBLE);
                        binding.progressCircular.setVisibility(View.GONE);
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(EditProfileActivity.this, e.getMessage()+"", Toast.LENGTH_SHORT).show();

                        //Show btn and Hide progress
                        binding.updateProfile.setVisibility(View.VISIBLE);
                        binding.progressCircular.setVisibility(View.GONE);
                    }
                });

    }

}

