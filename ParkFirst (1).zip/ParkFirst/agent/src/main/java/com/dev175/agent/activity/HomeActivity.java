package com.dev175.agent.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import com.bumptech.glide.Glide;
import com.dev175.agent.R;

import com.dev175.agent.databinding.ActivityHomeBinding;
import com.dev175.agent.model.Constant;
import com.dev175.agent.model.Agent;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class HomeActivity extends AppCompatActivity {

    //For Logs
    private static final String TAG = "HomeActivity";

    //For Binding
    private ActivityHomeBinding binding;

    //For Toggle Menu
    private ActionBarDrawerToggle actionBarDrawerToggle;

    //For Navigation Header Binding
    private com.dev175.agent.databinding.NavigationHeaderBinding navigationBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityHomeBinding.inflate(getLayoutInflater());
        View layout = binding.getRoot();
        setContentView(layout);
        init();

        setCurrentUser();

    }


    private void setCurrentUser()
    {
        if (Constant.currentUser==null)
        {
            String uid = FirebaseAuth.getInstance().getUid();
            DatabaseReference userRef = FirebaseDatabase.getInstance().getReference().child(Constant.ROOT_AGENT);

            try {
                userRef.child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Constant.currentUser = snapshot.getValue(Agent.class);

                        if (Constant.currentUser!=null)
                        {
                            Glide.with(HomeActivity.this)
                                    .load(Constant.currentUser.getUri())
                                    .placeholder(R.drawable.ic_user)
                                    .into(navigationBinding.userImg);
                            navigationBinding.name.setText(Constant.currentUser.getName());
                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Log.d(TAG, "onCancelled: "+error.getMessage());
                    }
                });
            }
            catch (Exception e)
            {
                Log.e(TAG, "setCurrentUser: "+e.getMessage() );
            }
        }
        else {
            Glide.with(HomeActivity.this)
                    .load(Constant.currentUser.getUri())
                    .placeholder(R.drawable.ic_user)
                    .into(navigationBinding.userImg);
            navigationBinding.name.setText(Constant.currentUser.getName());

        }

    }
    private void init() {
        setSupportActionBar(binding.toolBar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setTitle("Home");
        actionBarDrawerToggle = new ActionBarDrawerToggle(HomeActivity.this, binding.drawerLayout, R.string.drawer_open, R.string.drawer_close);
        binding.drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

        binding.navigationView.setItemIconTintList(null);
        ////Inflating navigation header view
        navigationBinding = com.dev175.agent.databinding.NavigationHeaderBinding.inflate(getLayoutInflater(),binding.navigationView,false);
        binding.navigationView.addHeaderView(navigationBinding.getRoot());

        /////////////click listener over Navigation drawer
        binding.navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                onItemSelect(item);
                return false;
            }
        });

        binding.checkSpace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    startActivity(new Intent(HomeActivity.this,CheckSpaceActivity.class));
            }
        });

        binding.parkings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this,AppointmentsActivity.class));
            }
        });


        binding.makeParking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this,TimeSlotActivity.class));
            }
        });

    }

    ////////////////this method is override to enable Toggle button
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Pass the event to ActionBarDrawerToggle, if it returns
        // true, then it has handled the app icon touch event
        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        // Handle your other action bar items...
        return super.onOptionsItemSelected(item);
    }

    private void onItemSelect(MenuItem item) {
        if (item.getItemId() == R.id.logout) {

            FirebaseAuth.getInstance().signOut();
            Constant.currentUser = null;
            Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }
        else if (item.getItemId() == R.id.editProfile)
        {
            if (Constant.currentUser!=null)
            {
                startActivity(new Intent(HomeActivity.this,EditProfileActivity.class));
            }
        }

    }

    @Override
    public void onBackPressed() {
        binding.drawerLayout.closeDrawers();
        super.onBackPressed();
    }

}