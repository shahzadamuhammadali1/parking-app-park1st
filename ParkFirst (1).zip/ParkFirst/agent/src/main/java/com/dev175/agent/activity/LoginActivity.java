package com.dev175.agent.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import com.dev175.agent.databinding.ActivityLoginBinding;
import com.dev175.agent.model.Constant;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LoginActivity extends AppCompatActivity {

    //For Logs
    private static final String TAG = "LoginActivity";

    //For Binding
    private ActivityLoginBinding binding;
    private FirebaseAuth firebaseAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);
        init();
    }

    private void init() {

        firebaseAuth = FirebaseAuth.getInstance();

        //Login Button Click Listener
        binding.loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginUser();
            }
        });

    }



    private void loginUser() {

        //This method will validate the textfields
        boolean result =validateLoginFields();

        if (result){
            //Show Progress & Hide Button
            binding.loginBtn.setVisibility(View.GONE);
            binding.progressCircular.setVisibility(View.VISIBLE);

            firebaseAuth.signInWithEmailAndPassword(binding.email.getText().toString(),binding.password.getText().toString())
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {

                            if (task.isSuccessful())
                            {

                                String uid = FirebaseAuth.getInstance().getUid();
                                DatabaseReference doctorDb = FirebaseDatabase.getInstance().getReference().child(Constant.ROOT_AGENT);
                                doctorDb.child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                        if (snapshot.exists())
                                        {

                                            //Show Btn & Hide Progress
                                            binding.progressCircular.setVisibility(View.GONE);
                                            binding.loginBtn.setVisibility(View.VISIBLE);


                                            //If email is verified then continue to login
                                            if (firebaseAuth.getCurrentUser().isEmailVerified())
                                            {

                                                Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                                startActivity(intent);
                                            }
                                            else
                                            {
                                                Toast.makeText(LoginActivity.this, "Please Verify your email..!", Toast.LENGTH_SHORT).show();
                                            }

                                        }
                                        else
                                        {
                                            //Show Btn & Hide Progress
                                            binding.progressCircular.setVisibility(View.GONE);
                                            binding.loginBtn.setVisibility(View.VISIBLE);

                                            FirebaseAuth.getInstance().signOut();
                                            Toast.makeText(LoginActivity.this, "This email is registered as Patient account", Toast.LENGTH_SHORT).show();
                                        }

                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {
                                        //Show Btn & Hide Progress
                                        binding.progressCircular.setVisibility(View.GONE);
                                        binding.loginBtn.setVisibility(View.VISIBLE);
                                        Toast.makeText(LoginActivity.this, error.getMessage()+"", Toast.LENGTH_SHORT).show();
                                    }
                                });

                            }
                            else
                            {
                                //Show Btn & Hide Progress
                                binding.progressCircular.setVisibility(View.GONE);
                                binding.loginBtn.setVisibility(View.VISIBLE);
                                Log.d(TAG, "onComplete: "+task.getException());
                                Toast.makeText(LoginActivity.this,task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }

    }

    private boolean validateLoginFields() {
        boolean isValid = true;

        //Email
        if (binding.email.getText().toString().isEmpty())
        {
            binding.emailLyt.setError("\u2022 Email is Required!");
            isValid = false;
        }
        else
        {
            binding.emailLyt.setErrorEnabled(false);
        }

        //Password
        if (binding.password.getText().toString().isEmpty())
        {
            binding.passwordLyt.setError("\u2022 Password is Required!");
            isValid = false;
        }
        else
        {
            binding.passwordLyt.setErrorEnabled(false);
        }

        return isValid;

    }



}