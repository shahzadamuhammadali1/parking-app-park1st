package com.dev175.agent.model;

import java.io.Serializable;

public class Appointment implements Serializable {
    private User user;
    private ParkingSlot parkingSlot;

    public Appointment() {
    }

    public Appointment(User user, ParkingSlot parkingSlot) {
        this.user = user;
        this.parkingSlot = parkingSlot;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public ParkingSlot getParkingSlot() {
        return parkingSlot;
    }

    public void setParkingSlot(ParkingSlot parkingSlot) {
        this.parkingSlot = parkingSlot;
    }
}
