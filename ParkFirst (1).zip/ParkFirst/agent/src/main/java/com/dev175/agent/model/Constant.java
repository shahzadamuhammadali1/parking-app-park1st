package com.dev175.agent.model;

import java.util.ArrayList;

public class Constant {

    public static final String ROOT_AGENT = "Agents";
    public static final String ROOT_SPACE = "Space";
    public static final String ROOT_PARKING = "Parkings";
    public static final String USER_APPOINTMENTS = "User Parkings";
    public static final String ROOT_USER = "Users";
    public static final String APPOINTMENT = "Appointment";
    public static final String NOT_CONFIRMED = "Not Confirmed";
    public static final String CONFIRMED = "Confirmed";
    public static final String STATUS = "status";
    public static final Object COMPLETED = "Completed";
    public static final String AGENT = "AGENT";
    public static final String TIMESLOT = "TIMESLOT";
    public static final String ROOT_EMAILS = "Emails";
    public static Agent currentUser;


    public static final String SELECT_VEHICLE_TYPE = "Select Vehicle Type";
    public static final String TWO_WHEELER = "Two Wheeler";
    public static final String THREE_WHEELER = "Three Wheeler";
    public static final String FOUR_WHEELER = "Four Wheeler";
    public static final String SIX_WHEELER = "Six Wheeler";

    public static final int TIME_SLOT_TOTAL = 40;

    public static String convertParkingSlotToString(int slot)
    {
        switch (slot)
        {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
                return "Two Wheeler";


            case 10:
            case 11:
            case 12:
            case 13:
            case 14:
            case 15:
            case 16:
            case 17:
            case 18:
            case 19:
                return "Three Wheeler";

            case 20:
            case 21:
            case 22:
            case 23:
            case 24:
            case 25:
            case 26:
            case 27:
            case 28:
            case 29:
                return "Four Wheeler";

            case 30:
            case 31:
            case 32:
            case 33:
            case 34:
            case 35:
            case 36:
            case 37:
            case 38:
            case 39:
                return "Six Wheeler";

            default:
                return "Closed";
        }
    }

    public static ArrayList<ParkingSlot> getParkingSlots()
    {
        ArrayList<ParkingSlot> slots = new ArrayList<>();
        slots.add(new ParkingSlot(0,Constant.TWO_WHEELER));
        slots.add(new ParkingSlot(1,Constant.TWO_WHEELER));
        slots.add(new ParkingSlot(2,Constant.TWO_WHEELER));
        slots.add(new ParkingSlot(3,Constant.TWO_WHEELER));
        slots.add(new ParkingSlot(4,Constant.TWO_WHEELER));
        slots.add(new ParkingSlot(5,Constant.TWO_WHEELER));
        slots.add(new ParkingSlot(6,Constant.TWO_WHEELER));
        slots.add(new ParkingSlot(7,Constant.TWO_WHEELER));
        slots.add(new ParkingSlot(8,Constant.TWO_WHEELER));
        slots.add(new ParkingSlot(9,Constant.TWO_WHEELER));
        slots.add(new ParkingSlot(10,Constant.THREE_WHEELER));
        slots.add(new ParkingSlot(11,Constant.THREE_WHEELER));
        slots.add(new ParkingSlot(12,Constant.THREE_WHEELER));
        slots.add(new ParkingSlot(13,Constant.THREE_WHEELER));
        slots.add(new ParkingSlot(14,Constant.THREE_WHEELER));
        slots.add(new ParkingSlot(15,Constant.THREE_WHEELER));
        slots.add(new ParkingSlot(16,Constant.THREE_WHEELER));
        slots.add(new ParkingSlot(17,Constant.THREE_WHEELER));
        slots.add(new ParkingSlot(18,Constant.THREE_WHEELER));
        slots.add(new ParkingSlot(19,Constant.THREE_WHEELER));
        slots.add(new ParkingSlot(20,Constant.FOUR_WHEELER));
        slots.add(new ParkingSlot(21,Constant.FOUR_WHEELER));
        slots.add(new ParkingSlot(22,Constant.FOUR_WHEELER));
        slots.add(new ParkingSlot(23,Constant.FOUR_WHEELER));
        slots.add(new ParkingSlot(24,Constant.FOUR_WHEELER));
        slots.add(new ParkingSlot(25,Constant.FOUR_WHEELER));
        slots.add(new ParkingSlot(26,Constant.FOUR_WHEELER));
        slots.add(new ParkingSlot(27,Constant.FOUR_WHEELER));
        slots.add(new ParkingSlot(28,Constant.FOUR_WHEELER));
        slots.add(new ParkingSlot(29,Constant.FOUR_WHEELER));
        slots.add(new ParkingSlot(30,Constant.SIX_WHEELER));
        slots.add(new ParkingSlot(31,Constant.SIX_WHEELER));
        slots.add(new ParkingSlot(32,Constant.SIX_WHEELER));
        slots.add(new ParkingSlot(33,Constant.SIX_WHEELER));
        slots.add(new ParkingSlot(34,Constant.SIX_WHEELER));
        slots.add(new ParkingSlot(35,Constant.SIX_WHEELER));
        slots.add(new ParkingSlot(36,Constant.SIX_WHEELER));
        slots.add(new ParkingSlot(37,Constant.SIX_WHEELER));
        slots.add(new ParkingSlot(38,Constant.SIX_WHEELER));
        slots.add(new ParkingSlot(39,Constant.SIX_WHEELER));

        return slots;
    }

}
