package com.dev175.agent.model;

import java.io.Serializable;

public class ParkingSlot implements Serializable {


    private String uid;
    private int slot;
    private String status;
    private String type;
    private String vehichleNum;
    private String userId;
    private String agentId;

    public ParkingSlot() {

    }

    public ParkingSlot(int slot,String type) {
        this.slot = slot;
        uid = "";
        this.type = type;
        this.status = "";
        userId = "";
        agentId = "";
        vehichleNum = "";

    }

    public String getVehichleNum() {
        return vehichleNum;
    }

    public void setVehichleNum(String vehichleNum) {
        this.vehichleNum = vehichleNum;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public int getSlot() {
        return slot;
    }

    public void setSlot(int slot) {
        this.slot = slot;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getAgentId() {
        return agentId;
    }

    public void setAgentId(String agentId) {
        this.agentId = agentId;
    }
}
