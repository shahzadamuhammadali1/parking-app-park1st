package com.dev175.agent.myInterface;

public interface IOnItemClick {
    void onItemClick(int position);
}
