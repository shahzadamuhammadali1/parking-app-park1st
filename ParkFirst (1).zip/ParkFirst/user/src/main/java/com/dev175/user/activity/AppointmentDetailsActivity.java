package com.dev175.user.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.bumptech.glide.Glide;
import com.dev175.user.R;
import com.dev175.user.databinding.ActivityAppointmentDetailsBinding;
import com.dev175.user.model.Appointment;
import com.dev175.user.model.Constant;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AppointmentDetailsActivity extends AppCompatActivity {

    //For Binding
    private ActivityAppointmentDetailsBinding binding;
    private Appointment appointment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAppointmentDetailsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        init();
    }

    private void init(){
        getSupportActionBar().setTitle("Booking Details");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        appointment = (Appointment) getIntent().getSerializableExtra(Constant.APPOINTMENT);

        if (appointment.getParkingSlot().getStatus().equals(Constant.COMPLETED))
        {
            binding.cancelAppointment.setVisibility(View.GONE);
        }
        
        //Set Data
        Glide.with(AppointmentDetailsActivity.this)
                .load(appointment.getAgent().getUri())
                .placeholder(R.drawable.ic_user)
                .into(binding.docProfileImg);

        binding.doctorName.setText(appointment.getAgent().getName());

        binding.phone.setText(appointment.getAgent().getPhoneNumber());
        binding.address.setText(appointment.getAgent().getAddress());
        binding.slot.setText(String.valueOf(appointment.getParkingSlot().getSlot()));
        binding.type.setText(appointment.getParkingSlot().getType());
        binding.status.setText(appointment.getParkingSlot().getStatus());
        binding.vehicleNum.setText(appointment.getParkingSlot().getVehichleNum());

        //Cancel Button Click Listener
        binding.cancelAppointment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cancelAppointment();
            }
        });
    }

    private void cancelAppointment() {
        String uid = FirebaseAuth.getInstance().getUid();

        DatabaseReference database = FirebaseDatabase.getInstance().getReference();

        String patientDocId = uid+"_"+appointment.getAgent().getUid();

        database.child(Constant.USER_APPOINTMENTS)
                .child(patientDocId)
                .child(appointment.getParkingSlot().getUid())
                .removeValue()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {

                        database.child(Constant.ROOT_PARKING)
                                .child(appointment.getAgent().getUid())
                                .child(String.valueOf(appointment.getParkingSlot().getSlot()))
                                .removeValue();

                        startActivity(new Intent(AppointmentDetailsActivity.this,HomeActivity.class));
                        finishAffinity();
                    }
                });


    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}