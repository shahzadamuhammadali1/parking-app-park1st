package com.dev175.user.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import com.dev175.user.adapter.AppointmentsAdapter;
import com.dev175.user.databinding.ActivityAppointmentsListBinding;
import com.dev175.user.model.Agent;
import com.dev175.user.model.Appointment;
import com.dev175.user.model.Constant;
import com.dev175.user.model.ParkingSlot;
import com.dev175.user.myInterface.IOnItemClick;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;

public class AppointmentsListActivity extends AppCompatActivity implements IOnItemClick {

    private ActivityAppointmentsListBinding binding;
    private DatabaseReference database;
    private static final String TAG = "AppointmentsListActivit";
    private ArrayList<Appointment> appointmentsList;
    private AppointmentsAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAppointmentsListBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        init();
        getAppointments();
    }

    private void getAppointments() {
        binding.progress.setVisibility(View.VISIBLE);
        database.child(Constant.USER_APPOINTMENTS)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        int count = 0;
                        for (DataSnapshot snapshot: dataSnapshot.getChildren())
                        {
                            count++;
                            String[] keys = snapshot.getKey().split("_");
                            
                            String uid = FirebaseAuth.getInstance().getUid();
                            if (keys[0].equals(uid))
                            {
                                database.child(Constant.ROOT_AGENT)
                                        .child(keys[1])
                                        .addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot docSnap) {
                                                Agent doctor =  docSnap.getValue(Agent.class);

                                                for (DataSnapshot dataSnapshot:snapshot.getChildren())
                                                {
                                                    ParkingSlot timeslot =  dataSnapshot.getValue(ParkingSlot.class);

                                                        Appointment appointment = new Appointment(doctor,timeslot);
                                                        appointmentsList.add(appointment);

                                                }

                                                adapter.notifyDataSetChanged();
                                                Log.d(TAG, "onChildAdded: "+appointmentsList.size());

                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError error) {

                                            }
                                        });


                            }
                        }
                        adapter.notifyDataSetChanged();

                        if (count>=dataSnapshot.getChildrenCount())
                        {
                            binding.progress.setVisibility(View.GONE);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull  DatabaseError error) {
                        binding.progress.setVisibility(View.GONE);
                        Toast.makeText(AppointmentsListActivity.this, ""+error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }



    private void init() {
        getSupportActionBar().setTitle("Bookings");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        database = FirebaseDatabase.getInstance().getReference();
        appointmentsList = new ArrayList<>();

        adapter = new AppointmentsAdapter(this,this);
        adapter.setAppointments(appointmentsList);
        binding.appointmentsRv.setLayoutManager(new LinearLayoutManager(this));
        binding.appointmentsRv.setAdapter(adapter);

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onItemClick(int position) {
        Appointment appointment = appointmentsList.get(position);
        Intent intent = new Intent(AppointmentsListActivity.this,AppointmentDetailsActivity.class);
        intent.putExtra(Constant.APPOINTMENT,appointment);
        startActivity(intent);
    }
}

