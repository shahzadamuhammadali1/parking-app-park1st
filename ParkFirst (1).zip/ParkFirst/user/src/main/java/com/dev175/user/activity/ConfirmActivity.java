package com.dev175.user.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import com.dev175.user.R;

import com.dev175.user.databinding.ActivityConfirmBinding;
import com.dev175.user.model.Agent;
import com.dev175.user.model.Constant;
import com.dev175.user.model.ParkingSlot;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ConfirmActivity extends AppCompatActivity {

    private ActivityConfirmBinding binding;
    private Agent doctor;
    private ParkingSlot timeslot;
    private DatabaseReference database;
    private boolean isAlreadyReserved;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityConfirmBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        init();

    }

    private void checkUserParking() {
        String uid = FirebaseAuth.getInstance().getUid();
        String userAgentId = uid+"_"+doctor.getUid();
        database.child(Constant.USER_APPOINTMENTS)
                .child(userAgentId)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        isAlreadyReserved = snapshot.exists();

                    }

                    @Override
                    public void onCancelled(@NonNull  DatabaseError error) {

                    }
                });
    }

    private void init() {
        getSupportActionBar().setTitle("Confirm Appointment");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        doctor = (Agent) getIntent().getSerializableExtra(Constant.DOCTOR);
        timeslot = (ParkingSlot) getIntent().getSerializableExtra(Constant.TIMESLOT);
        database = FirebaseDatabase.getInstance().getReference();

        if (doctor!=null)
        {
            Glide.with(ConfirmActivity.this)
                    .load(doctor.getUri())
                    .placeholder(R.drawable.ic_user)
                    .into(binding.docProfileImg);
            binding.doctorName.setText(doctor.getName());

            binding.phone.setText(doctor.getPhoneNumber());
            binding.address.setText(doctor.getAddress());
            checkUserParking();
        }
        if (timeslot!=null)
        {
            binding.slot.setText(String.valueOf(timeslot.getSlot()));
            binding.type.setText(new StringBuilder(Constant.convertParkingSlotToString(timeslot.getSlot())));
        }


        binding.confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (binding.vehicleNum.getText().toString().isEmpty())
                {
                    binding.vehicleLyt.setError("\u2022 Vehicle number is Required!");
                    return;
                }
                else
                {
                    binding.vehicleLyt.setErrorEnabled(false);
                }

                if (isAlreadyReserved)
                {
                    Toast.makeText(ConfirmActivity.this, "You have already booked a parking!", Toast.LENGTH_SHORT).show();
                    return;
                }

                String key = database.push().getKey();
                timeslot.setAgentId(doctor.getUid());
                timeslot.setUserId(FirebaseAuth.getInstance().getUid());
                timeslot.setUid(key);
                timeslot.setStatus(Constant.NOT_CONFIRMED);
                timeslot.setVehichleNum(binding.vehicleNum.getText().toString());
                database.child(Constant.ROOT_PARKING)
                        .child(doctor.getUid())
                        .child(String.valueOf(timeslot.getSlot()))
                        .setValue(timeslot)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                saveUserAppointment();
                                Toast.makeText(ConfirmActivity.this, "Booking Successful!", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(ConfirmActivity.this,HomeActivity.class);
                                startActivity(intent);
                                finishAffinity();
                            }
                        });

            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    private void saveUserAppointment() {
        database.child(Constant.USER_APPOINTMENTS)
                .child(Constant.currentUser.getUid()+"_"+doctor.getUid())
                .child(timeslot.getUid())
                .setValue(timeslot);
    }
}