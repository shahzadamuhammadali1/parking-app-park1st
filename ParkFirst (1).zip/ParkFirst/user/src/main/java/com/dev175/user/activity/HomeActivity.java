package com.dev175.user.activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.dev175.user.R;
import com.dev175.user.adapter.AppointmentsAdapter;

import com.dev175.user.databinding.ActivityHomeBinding;
import com.dev175.user.model.Appointment;
import com.dev175.user.model.Constant;
import com.dev175.user.model.User;
import com.dev175.user.myInterface.IOnItemClick;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


public class HomeActivity extends AppCompatActivity implements IOnItemClick {

    //For Logs
    private static final String TAG = "HomeActivity";

    //For Binding
    private ActivityHomeBinding binding;


    private DatabaseReference database;
    private ArrayList<Appointment> appointmentsList;
    private AppointmentsAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityHomeBinding.inflate(getLayoutInflater());
        View layout = binding.getRoot();
        setContentView(layout);

        init();

        setCurrentUser();

    }


    private void setCurrentUser()
    {
        if (Constant.currentUser==null)
        {
            String uid = FirebaseAuth.getInstance().getUid();
            DatabaseReference userRef = database.child(Constant.ROOT_USER);

            try {
                userRef.child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Constant.currentUser = snapshot.getValue(User.class);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Log.d(TAG, "onCancelled: "+error.getMessage());
                    }
                });
            }
            catch (Exception e)
            {
                Log.e(TAG, "setCurrentUser: "+e.getMessage() );
            }
        }

    }

    private void init() {
        setSupportActionBar(binding.toolBar);
        getSupportActionBar().setTitle("Home");

        database = FirebaseDatabase.getInstance().getReference();
        appointmentsList = new ArrayList<>();

        adapter = new AppointmentsAdapter(this,this);
        adapter.setAppointments(appointmentsList);

        binding.bottomNavigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId()==R.id.appointments)
                {
                    if (Constant.currentUser!=null)
                    {
                        startActivity(new Intent(HomeActivity.this, AppointmentsListActivity.class));
                        return true;
                    }

                    return false;
                }
                else if (item.getItemId()==R.id.editProfile)
                {
                    if (Constant.currentUser!=null)
                    {
                        startActivity(new Intent(HomeActivity.this, EditProfileActivity.class));
                        return true;
                    }
                    return false;
                }
                else
                {
                    return false;
                }

            }
        });

        binding.makeAppointment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this,TimeSlotActivity.class));
            }
        });
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.action_signOut) {
            FirebaseAuth.getInstance().signOut();
            Constant.currentUser = null;

            //open Home Activity
            Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public void onItemClick(int position) {
        Appointment appointment = appointmentsList.get(position);
        Intent intent = new Intent(HomeActivity.this,AppointmentDetailsActivity.class);
        intent.putExtra(Constant.APPOINTMENT,appointment);
        startActivity(intent);

    }
}