package com.dev175.user.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.dev175.user.R;
import com.dev175.user.databinding.ActivitySignupBinding;
import com.dev175.user.model.Constant;
import com.dev175.user.model.User;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import java.io.ByteArrayOutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SignupActivity extends AppCompatActivity {

    private static final String TAG = "SignupActivity";

    //For Binding
    ActivitySignupBinding binding;

    //Select Image Request Code
    private static final int IMAGE_REQUEST_CODE=125;

    //Selected Image Uri
    private Uri imageUri;

    //User
    private User user;

    //Storage & Db Reference
    private StorageReference distributorImagesRef;
    private DatabaseReference distributorRef;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySignupBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);

        init();
    }



    private void init() {

        user = new User();
        firebaseAuth = FirebaseAuth.getInstance();

        //Storage Reference
        distributorImagesRef= FirebaseStorage.getInstance().getReference().child(Constant.ROOT_USER);

        //Database Reference
        distributorRef = FirebaseDatabase.getInstance().getReference().child(Constant.ROOT_USER);


        //User Profile Click Listener
        binding.userProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectImageFromGallery();
            }
        });

        //Signup Click Listener
        binding.signupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signUp();
            }
        });

        //Login Click Listener
        binding.loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showLoginActivity();
            }
        });
    }


    private void showLoginActivity() {
        startActivity(new Intent(SignupActivity.this, LoginActivity.class));
    }

    private void signUp() {
        boolean checkFields = validateLoginFields();

        if (checkFields)
        {
            signUpUser();
        }
    }

    private void signUpUser() {
        //Show Progress and Hide Button
        binding.signupBtn.setVisibility(View.GONE);
        binding.progressCircular.setVisibility(View.VISIBLE);

        firebaseAuth.createUserWithEmailAndPassword(binding.email.getText().toString(), binding.password.getText().toString())
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if (task.isSuccessful()) //If user sign up successfully
                        {
                            firebaseAuth.getCurrentUser()
                                    .sendEmailVerification()
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {

                                                user.setName(binding.name.getText().toString());
                                                user.setEmail(binding.email.getText().toString());
                                                user.setAddress(binding.address.getText().toString());

                                                user.setPhoneNumber(binding.phone.getText().toString());
                                                user.setUid(firebaseAuth.getUid());
                                                if (imageUri==null)
                                                {
                                                    user.setUri("");
                                                    saveUserInfoToDatabase();
                                                }
                                                else
                                                {
                                                    //Optimize Img
                                                    ExecutorService executors = Executors.newSingleThreadExecutor();
                                                    executors.execute(new Runnable() {
                                                        @Override
                                                        public void run() {

                                                            Bitmap bitmap = null;
                                                            try {

                                                                if(Build.VERSION.SDK_INT < 28) {

                                                                    bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);
                                                                } else {
                                                                    ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), imageUri);
                                                                    bitmap = ImageDecoder.decodeBitmap(source);
                                                                }

                                                            }
                                                            catch (Exception e) {
                                                                Log.e("TAG", "onActivityResult: "+e.getMessage() );
                                                            }

                                                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                            if (bitmap != null) {
                                                                bitmap.compress(Bitmap.CompressFormat.JPEG, 75, baos);
                                                            }
                                                            byte[] data = baos.toByteArray();

                                                            //User Id
                                                            String uid = FirebaseAuth.getInstance().getUid();
                                                            distributorImagesRef = distributorImagesRef.child(uid+".jpg");
                                                            final UploadTask uploadTask=distributorImagesRef.putBytes(data);
                                                            uploadTask.addOnFailureListener(new OnFailureListener() {
                                                                @Override
                                                                public void onFailure(@NonNull Exception e) {
                                                                    String message=e.toString();
                                                                    Toast.makeText(SignupActivity.this, "Error : "+message, Toast.LENGTH_SHORT).show();

                                                                    //Show Btn and Hide Progress
                                                                    binding.signupBtn.setVisibility(View.VISIBLE);
                                                                    binding.progressCircular.setVisibility(View.GONE);
                                                                }
                                                            }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                                                @Override
                                                                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                                                    Task<Uri> uriTask=uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                                                                        @Override
                                                                        public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                                                                            if (!task.isSuccessful())
                                                                            {
                                                                                throw task.getException();
                                                                            }

                                                                            return distributorImagesRef.getDownloadUrl();
                                                                        }
                                                                    }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                                                                        @Override
                                                                        public void onComplete(@NonNull Task<Uri> task) {
                                                                            if (task.isSuccessful())
                                                                            {
                                                                                user.setUri(task.getResult().toString());
                                                                                saveUserInfoToDatabase();
                                                                            }
                                                                        }
                                                                    });
                                                                };
                                                            });

                                                        }
                                                    });
                                                }


                                            } else {
                                                Log.d(TAG, "onComplete: "+task.getException());
                                                Toast.makeText(SignupActivity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                            }

                                        }
                                    });

                        } else //if any error occurs
                        {
                            //Show Progress and Hide Button
                            binding.progressCircular.setVisibility(View.GONE);
                            binding.signupBtn.setVisibility(View.VISIBLE);

                            Toast.makeText(SignupActivity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }



    private void saveUserInfoToDatabase() {

        //User Id
        String uid = FirebaseAuth.getInstance().getUid();

        if (uid != null)
        {

            distributorRef.child(uid).setValue(user)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {

                            FirebaseDatabase.getInstance().getReference().child(Constant.ROOT_EMAILS)
                                    .child(uid)
                                    .setValue(user.getEmail());

                            Toast.makeText(SignupActivity.this, "Sign up Successful.\nPlease verify your email to Login.", Toast.LENGTH_SHORT).show();
                            resetFields();

                            //Show Progress and Hide Button
                            binding.signupBtn.setVisibility(View.VISIBLE);
                            binding.progressCircular.setVisibility(View.GONE);
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(SignupActivity.this, e.getMessage()+"", Toast.LENGTH_SHORT).show();

                            //Show Progress and Hide Button
                            binding.signupBtn.setVisibility(View.VISIBLE);
                            binding.progressCircular.setVisibility(View.GONE);
                        }
                    });
        }

    }

    private void resetFields() {
        binding.name.setText("");
        binding.email.setText("");
        binding.password.setText("");
        binding.phone.setText("");
        binding.address.setText("");
        binding.userProfile.setImageResource(R.drawable.ic_user);
    }

    private boolean validateLoginFields() {
        boolean isValid = true;

        //Name
        if (binding.name.getText().toString().isEmpty())
        {
            binding.nameLyt.setError("\u2022 Name is Required!");
            isValid = false;
        }
        else
        {
            binding.nameLyt.setErrorEnabled(false);
        }

        //Email
        if (binding.email.getText().toString().isEmpty())
        {
            binding.emailLyt.setError("\u2022 Email is Required!");
            isValid = false;
        }
        else
        {
            binding.emailLyt.setErrorEnabled(false);
        }

        //Password
        if (binding.password.getText().toString().isEmpty())
        {
            binding.passwordLyt.setError("\u2022 Password is Required!");
            isValid = false;
        }
        else
        {
            binding.passwordLyt.setErrorEnabled(false);
        }

        //Phone Number
        if (binding.phone.getText().toString().isEmpty())
        {
            binding.phoneLyt.setError("\u2022 Phone number is Required!");
            isValid = false;
        }
        else
        {
            binding.phoneLyt.setErrorEnabled(false);
        }

        //Address
        if (binding.address.getText().toString().isEmpty())
        {
            binding.addressLyt.setError("\u2022 Address is Required!");
            isValid = false;
        }
        else
        {
            binding.addressLyt.setErrorEnabled(false);
        }

        return isValid;

    }


    //Open Gallery and Select Image
    private void selectImageFromGallery() {
        Intent galleryIntent=new Intent();
        galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
        galleryIntent.setType("image/*");
        startActivityForResult(galleryIntent,IMAGE_REQUEST_CODE);
    }

    //On Result
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == IMAGE_REQUEST_CODE && resultCode==RESULT_OK && data!=null && data.getData()!=null)
        {
            imageUri=data.getData();

            binding.userProfile.setImageURI(imageUri);
        }


    }

}
