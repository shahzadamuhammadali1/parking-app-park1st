package com.dev175.user.activity;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.dev175.user.adapter.TimeSlotAdapter;

import com.dev175.user.databinding.ActivityTimeSlotBinding;
import com.dev175.user.model.Agent;
import com.dev175.user.model.Constant;
import com.dev175.user.model.ParkingSlot;
import com.dev175.user.myInterface.IOnItemClick;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class TimeSlotActivity extends AppCompatActivity implements IOnItemClick {

    private ActivityTimeSlotBinding binding;

    private Agent agent;
    private static final String TAG = "TimeSlotActivity";
    private DatabaseReference database;
    private TimeSlotAdapter adapter;
    private ArrayList<ParkingSlot> timeslots;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding  = ActivityTimeSlotBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        init();

    }


    private void getAppointments() {
        database.child(Constant.ROOT_PARKING)
                .child(agent.getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull  DataSnapshot snapshot) {
                        timeslots = Constant.getParkingSlots();

                        if (snapshot.exists())
                        {
                            //There are some bookings
                            for (DataSnapshot ds : snapshot.getChildren())
                            {
                                ParkingSlot timeslot = ds.getValue(ParkingSlot.class);
                                timeslots.set(timeslot.getSlot(),timeslot);

                            }

                            Log.d(TAG, "onDataChange: "+timeslots.size());
                            Log.d(TAG, "onDataChange: "+timeslots);
                            adapter.setTimeslots(timeslots);
                            binding.timeSlotRv.setAdapter(adapter);
                            adapter.notifyDataSetChanged();
                        }
                        else {

                            adapter.setTimeslots(timeslots);
                            binding.timeSlotRv.setAdapter(adapter);

                        }
                    }

                    @Override
                    public void onCancelled(@NonNull  DatabaseError error) {

                    }
                });
    }


    private void init() {
        getSupportActionBar().setTitle("Select Vehicle Type");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        adapter = new TimeSlotAdapter(this,this);
        binding.timeSlotRv.setLayoutManager(new GridLayoutManager(this,2,GridLayoutManager.VERTICAL,false));

        database = FirebaseDatabase.getInstance().getReference();
        if (agent==null)
        {

            database.child(Constant.ROOT_AGENT).addChildEventListener(new ChildEventListener() {
                @Override
                public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                  agent =   snapshot.getValue(Agent.class);

                    getAppointments();
                }

                @Override
                public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                }

                @Override
                public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                }

                @Override
                public void onChildMoved(@NonNull  DataSnapshot snapshot, @Nullable  String previousChildName) {

                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }

    }


    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onItemClick(int position) {
        ParkingSlot timeslot = timeslots.get(position);
        timeslot.setUid(Constant.currentUser.getUid());

        Intent intent = new Intent(TimeSlotActivity.this,ConfirmActivity.class);
        intent.putExtra(Constant.DOCTOR, agent);
        intent.putExtra(Constant.TIMESLOT,timeslot);
        startActivity(intent);

    }

}