package com.dev175.user.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.dev175.user.R;
import com.dev175.user.databinding.ItemAppointmentBinding;
import com.dev175.user.model.Appointment;
import com.dev175.user.myInterface.IOnItemClick;

import java.util.ArrayList;

public class AppointmentsAdapter  extends RecyclerView.Adapter<AppointmentsAdapter.ViewHolder> {

    private ArrayList<Appointment> appointments;
    private IOnItemClick iOnItemClick;
    private Context context;

    public AppointmentsAdapter(Context context,IOnItemClick iOnItemClick) {
        this.context = context;
        this.iOnItemClick = iOnItemClick;
    }
    public void setAppointments(ArrayList<Appointment> appointmentsList)
    {
        this.appointments = appointmentsList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_appointment,parent,false);
        return new ViewHolder(view,iOnItemClick);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Appointment appointment = appointments.get(position);


        Glide.with(context)
                .load(appointment.getAgent().getUri())
                .placeholder(R.drawable.ic_user)
                .into(holder.binding.docProfileImg);

        holder.binding.doctorName.setText(appointment.getAgent().getName());
        holder.binding.slot.setText(String.valueOf(appointment.getParkingSlot().getSlot()));
        holder.binding.type.setText(appointment.getParkingSlot().getType());
        holder.binding.status.setText(appointment.getParkingSlot().getStatus());


    }

    @Override
    public int getItemCount() {
        return appointments.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ItemAppointmentBinding binding;
        private IOnItemClick clickListener;

        public ViewHolder(@NonNull View itemView,IOnItemClick iOnItemClick) {
            super(itemView);
            binding = ItemAppointmentBinding.bind(itemView);
            this.clickListener = iOnItemClick;
            this.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    clickListener.onItemClick(getAdapterPosition());
                }
            });
        }
    }
}
