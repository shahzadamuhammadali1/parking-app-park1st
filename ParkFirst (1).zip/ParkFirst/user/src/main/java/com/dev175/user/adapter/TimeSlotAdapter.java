package com.dev175.user.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.dev175.user.R;
import com.dev175.user.databinding.ItemTimeSlotBinding;
import com.dev175.user.model.Constant;
import com.dev175.user.model.ParkingSlot;
import com.dev175.user.myInterface.IOnItemClick;

import java.util.ArrayList;

public class TimeSlotAdapter extends RecyclerView.Adapter<TimeSlotAdapter.ViewHolder> {

    private ArrayList<ParkingSlot> timeslots;
    private IOnItemClick timeSlotClick;
    private Context context;

    public TimeSlotAdapter( IOnItemClick click,Context context) {
        this.timeSlotClick = click;
        this.context = context;
    }
    public void setTimeslots(ArrayList<ParkingSlot> timeslots)
    {
        this.timeslots = timeslots;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_time_slot,parent,false);
        return new ViewHolder(view,timeSlotClick);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ParkingSlot timeslot = timeslots.get(position);
        holder.binding.timeSlot.setText(timeslot.getType());
        if (!timeslot.getUid().equals(""))
        {
            holder.binding.description.setText("Full");
            holder.binding.cardLyt.setBackgroundColor(context.getResources().getColor(R.color.green));
            holder.binding.description.setTextColor(context.getResources().getColor(R.color.white));
            holder.binding.timeSlot.setTextColor(context.getResources().getColor(R.color.white));
            holder.binding.cardLyt.setEnabled(false);
        }
        else
        {
            holder.binding.description.setText("Available");
        }


    }

    @Override
    public int getItemCount() {
        return Constant.TIME_SLOT_TOTAL;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ItemTimeSlotBinding binding;
        private IOnItemClick clickListener;

        public ViewHolder(@NonNull View itemView,IOnItemClick iOnQualificationClick) {
            super(itemView);
            binding = ItemTimeSlotBinding.bind(itemView);
            this.clickListener = iOnQualificationClick;
            this.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    clickListener.onItemClick(getAdapterPosition());
                }
            });
        }
    }
}
