package com.dev175.user.model;

import java.io.Serializable;

public class Appointment  implements Serializable {
    private Agent agent;
    private ParkingSlot parkingSlot;

    public Appointment() {
    }

    public Appointment(Agent agent, ParkingSlot parkingSlot) {
        this.agent = agent;
        this.parkingSlot = parkingSlot;
    }

    public Agent getAgent() {
        return agent;
    }

    public void setAgent(Agent agent) {
        this.agent = agent;
    }

    public ParkingSlot getParkingSlot() {
        return parkingSlot;
    }

    public void setParkingSlot(ParkingSlot parkingSlot) {
        this.parkingSlot = parkingSlot;
    }
}
