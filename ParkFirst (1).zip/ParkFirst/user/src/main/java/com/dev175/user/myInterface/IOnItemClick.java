package com.dev175.user.myInterface;

public interface IOnItemClick {
    void onItemClick(int position);
}
